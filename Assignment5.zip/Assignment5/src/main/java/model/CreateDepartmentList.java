package model;

import java.util.ArrayList;
import java.util.List;
/*
     instantiates our model class with the data from CSV Reader
 */
public class CreateDepartmentList {
    List<Department> departmentList = new ArrayList<>();
    private final static int SEMESTER_INDEX = 0;
    private final static int DEPARTMENT_INDEX = 1;
    private final static int COURSE_INDEX = 2;
    private final static int LOCATION_INDEX = 3;
    private final static int ENROLLMENT_CAP_INDEX = 4;
    private final static int ENROLLMENT_TOTAL_INDEX = 5;
    private final static int INSTRUCTOR_INDEX = 6;
    private final static int COMPONENT_CODE_INDEX = 7;

    public CreateDepartmentList() {
        createDepartmentList();
    }
    private void createDepartmentList() {
        String FILE_NAME = "data\\course_data_2018.csv";
        CsvReader courseData = new CsvReader(FILE_NAME);
        List<String[]> courseDataList = courseData.getListOfCsvRows();

        for (String[] index : courseDataList) {
            String curDeptName = index[DEPARTMENT_INDEX];
            Department newDepartment = new Department(curDeptName);
            Course curCourse = new Course(index[COURSE_INDEX]);
            Offering curOffering = new Offering(index[LOCATION_INDEX], index[INSTRUCTOR_INDEX], index[SEMESTER_INDEX]);
            Section curSection = new Section(index[COMPONENT_CODE_INDEX], index[ENROLLMENT_TOTAL_INDEX], index[ENROLLMENT_CAP_INDEX]);

            createModel(curDeptName, newDepartment, curCourse, curOffering, curSection);
        }
    }

    private void createModel(String curDeptName, Department newDepartment, Course curCourse, Offering curOffering, Section curSection) {
        if (isInDepartmentList(newDepartment)) {
            for (Department dept : departmentList) {
                if (dept.getName().equals(curDeptName)) {
                    dept.addToCourseList(curCourse, curOffering, curSection);
                }
            }
        } else {
            newDepartment.setDeptId(departmentList.size());
            departmentList.add(newDepartment);
            newDepartment.addToCourseList(curCourse, curOffering, curSection);
        }
    }

    public List<Department> getDepartmentList() {
        return departmentList;
    }

    private boolean isInDepartmentList(Department department) {
        for (Department dept : departmentList) {
            if (dept.getName().equals(department.getName())) {
                return true;
            }
        }
        return false;
    }
}
